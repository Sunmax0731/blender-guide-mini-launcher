# UI/UX Polish

## Closed Alpha で反映済み

- pass / warn / fail を同じ語彙で扱う。
- 警告時に次アクションを明示する。
- 手動テスト手順に入力、操作、期待結果、確認ファイルを具体化する。
- Blender アドオン導入前に使える CLI と Blender Python host adapter の入口を repo 内に置き、ユーザーが次の確認先を探さなくてよい状態にする。

## MVP 後の改善

- 実データ取り込み UI。
- 結果差分の比較表示。
- 手動承認コメントのテンプレート化。
- 公開先 GitHub Release / BOOTH 向けのサンプル画像と FAQ。
